var temperatura =Number(prompt("Informe a temperatura em F°"))
let operacao = temperatura - 32
let operacao2 = operacao * 0.556
alert(operacao2)