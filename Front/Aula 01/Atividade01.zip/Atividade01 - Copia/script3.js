var numero = Number(prompt("Digite um número"))
let potencia = numero ** 3
alert(potencia)