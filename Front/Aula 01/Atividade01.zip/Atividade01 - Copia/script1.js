var nome = prompt("Digite o seu nome: ")
var sobrenome = prompt("Digite seu sobrenome: ")
console.log (nome + sobrenome)