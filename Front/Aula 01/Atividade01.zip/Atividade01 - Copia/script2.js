var numero1 = Number (prompt("Digite o numero1"))
var numero2 = Number (prompt("Digite o numero2"))
var soma = numero1 + numero2
alert(soma)

var numero3 = Number (prompt("Digite o numero3"))
var numero4 = Number (prompt("Digite o numero4"))
var subtracao = numero3 - numero4
alert(subtracao)

var numero5 = Number (prompt("Digite o numero5"))
var numero6 = Number (prompt("Digite o numero6"))
var multiplicacao = numero5 * numero6
alert(multiplicacao)

var numero8 = Number (prompt("Digite o numero8"))
var numero9 = Number (prompt("Digite o numero9"))
var divisao = numero8 / numero9
alert(divisao)


