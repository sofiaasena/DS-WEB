function trocarFundoAzul(){
    document.body.style.backgroundColor="blue"
    document.getElementById("1").innerText="Subtítulo"

}
function trocarFundoVerde(){
    document.body.style.backgroundColor="green"
    document.getElementById("1").innerText="Texto"

}
function trocarFundoVermelho(){
    document.body.style.backgroundColor="red"
    document.getElementById("1").innerText="Comentário"

}